<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
set_time_limit(0);

header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET");

$servername = "174.141.233.174";
$username = "email_id";
$password = "55y60jgW*";
$database = "email_id";

$dbConfig = [
    'host' => $servername,
    'username' => $username,
    'password' => $password,
    'name' => $database,
    'port' => 3306 // or your actual port if different
];


$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
}
echo "✅ Connected successfully to remote DB!";


define('BATCH_SIZE', 1000);
define('MAX_PROCESSES', function_exists('pcntl_fork') ? 8 : 1);
define('LOG_FILE', __DIR__ . '/storage/smtp_verification.log');

// Initialize log file
if (!file_exists(LOG_FILE)) {
    file_put_contents(LOG_FILE, "Email Verification Log\n");
}

// --- LOGGING ---
function logMessage($message)
{
    $timestamp = date('Y-m-d H:i:s');
    file_put_contents(LOG_FILE, "[$timestamp] $message\n", FILE_APPEND);
    echo "[$timestamp] $message\n"; // Also output to console for real-time monitoring
}

// --- DOMAIN VERIFICATION ---
function getDomainIP($domain)
{
    if (getmxrr($domain, $mxhosts)) {
        $mxIp = @gethostbyname($mxhosts[0]);
        if ($mxIp !== $mxhosts[0]) {
            return $mxIp;
        }
    }
    $aRecord = @gethostbyname($domain);
    return ($aRecord !== $domain) ? $aRecord : false;
}

function processDomainsParallel($dbConfig)
{
    $mainConn = new mysqli(
        $dbConfig['host'],
        $dbConfig['username'],
        $dbConfig['password'],
        $dbConfig['name'],
        $dbConfig['port']
    );
    $mainConn->set_charset("utf8mb4");

    $totalDomains = $mainConn->query("SELECT COUNT(*) FROM emails WHERE domain_verified = 0")->fetch_row()[0];
    if ($totalDomains == 0) {
        logMessage("No domains to verify.");
        $mainConn->close();
        return 0;
    }

    $batches = ceil($totalDomains / BATCH_SIZE);
    logMessage("Starting domain verification: $totalDomains domains, $batches batches");

    $processed = 0;

    for ($i = 0; $i < $batches; $i++) {
        $offset = $i * BATCH_SIZE;
        $domains = $mainConn->query("SELECT id, sp_domain FROM emails WHERE domain_verified = 0 LIMIT $offset, " . BATCH_SIZE);
        if (!$domains) {
            logMessage("Batch $i: Query failed: " . $mainConn->error);
            continue;
        }

        while ($row = $domains->fetch_assoc()) {
            $domain = $row['sp_domain'];
            $ip = false;

            if (filter_var($domain, FILTER_VALIDATE_DOMAIN, FILTER_FLAG_HOSTNAME)) {
                $ip = getDomainIP($domain);
            }

            $status = $ip ? 1 : 0;
            $response = $ip ?: "Invalid domain";

            $update = $mainConn->prepare("UPDATE emails SET 
                domain_verified = 1,
                domain_status = ?,
                validation_response = ?,
                validation_status = ?
                WHERE id = ?");

            if (!$update) {
                logMessage("Batch $i: Prepare failed for ID {$row['id']}: " . $mainConn->error);
                continue;
            }

            $validationStatus = $status ? 'valid' : 'invalid';
            $update->bind_param("issi", $status, $response, $validationStatus, $row['id']);

            if (!$update->execute()) {
                logMessage("Batch $i: Update failed for ID {$row['id']}: " . $update->error);
            } else {
                $processed++;
                logMessage("Domain verified: {$row['id']} - $domain - Status: $status");
            }

            $update->close();
            usleep(20000); // 20ms delay
        }
    }

    $mainConn->close();
    logMessage("Domain verification completed. Processed: $processed domains");
    return $processed;
}

// --- SMTP VERIFICATION ---
function verifyEmailViaSMTP($email, $domain)
{
    if (!getmxrr($domain, $mxhosts)) {
        logMessage("SMTP: No MX record for $domain");
        return ["status" => "error", "result" => 0, "message" => "No MX record found"];
    }

    $mxIP = gethostbyname($mxhosts[0]);
    $port = 25;
    $timeout = 30;

    $smtp = @stream_socket_client(
        "tcp://$mxIP:$port",
        $errno,
        $errstr,
        $timeout
    );

    if (!$smtp) {
        logMessage("SMTP: Connection failed for $email@$domain: $errstr");
        return ["status" => "error", "result" => 0, "message" => "Connection failed: $errstr"];
    }

    stream_set_timeout($smtp, $timeout);
    $response = fgets($smtp, 4096);

    if (substr($response, 0, 3) != "220") {
        fclose($smtp);
        logMessage("SMTP: Server not ready for $email@$domain");
        return ["status" => "error", "result" => 0, "message" => "SMTP server not ready"];
    }

    fputs($smtp, "EHLO server.relyon.co.in\r\n");
    while ($line = fgets($smtp, 4096)) {
        if (substr($line, 3, 1) == " ")
            break;
    }

    fputs($smtp, "MAIL FROM:<info@relyon.co.in>\r\n");
    fgets($smtp, 4096);

    fputs($smtp, "RCPT TO:<$email>\r\n");
    $response = fgets($smtp, 4096);
    $responseCode = substr($response, 0, 3);

    fputs($smtp, "QUIT\r\n");
    fclose($smtp);

    // Determine status based on SMTP response code
    if ($responseCode == "250" || $responseCode == "251") {
        return ["status" => "success", "result" => 1, "message" => $mxIP];
    } elseif ($responseCode == "450" || $responseCode == "451" || $responseCode == "452") {
        return ["status" => "success", "result" => 2, "message" => "Temporary failure: $response"];
    } else {
        return ["status" => "success", "result" => 0, "message" => "Invalid: $response"];
    }
}

function processSmtpParallel($dbConfig)
{
    $mainConn = new mysqli(
        $dbConfig['host'],
        $dbConfig['username'],
        $dbConfig['password'],
        $dbConfig['name'],
        $dbConfig['port']
    );
    $mainConn->set_charset("utf8mb4");

    $totalEmails = $mainConn->query("SELECT COUNT(*) FROM emails WHERE domain_status = 1 AND domain_processed = 0")->fetch_row()[0];
    if ($totalEmails == 0) {
        logMessage("No emails to verify via SMTP.");
        $mainConn->close();
        return 0;
    }

    $batches = ceil($totalEmails / BATCH_SIZE);
    logMessage("Starting SMTP verification: $totalEmails emails, $batches batches");

    $processed = 0;

    for ($i = 0; $i < $batches; $i++) {
        $offset = $i * BATCH_SIZE;
        $emails = $mainConn->query("SELECT id, raw_emailid, sp_domain FROM emails WHERE domain_status = 1 AND domain_processed = 0 LIMIT $offset, " . BATCH_SIZE);
        if (!$emails) {
            logMessage("SMTP Batch $i: Query failed: " . $mainConn->error);
            continue;
        }

        while ($row = $emails->fetch_assoc()) {
            $email = $row['raw_emailid'];
            $domain = $row['sp_domain'];
            $verification = verifyEmailViaSMTP($email, $domain);

            $status = $verification['result']; // 0, 1, or 2
            $message = $mainConn->real_escape_string($verification['message']);
            $validationStatus = ($status == 1) ? 'valid' : (($status == 2) ? 'retry' : 'invalid');

            $update = $mainConn->prepare("UPDATE emails SET 
                domain_status = ?,
                validation_response = ?,
                domain_processed = 1,
                validation_status = ?
                WHERE id = ?");

            if (!$update) {
                logMessage("SMTP Batch $i: Prepare failed for ID {$row['id']}: " . $mainConn->error);
                continue;
            }

            $update->bind_param("issi", $status, $message, $validationStatus, $row['id']);

            if (!$update->execute()) {
                logMessage("SMTP Batch $i: Update failed for ID {$row['id']}: " . $update->error);
            } else {
                $processed++;
                logMessage("SMTP verified: {$row['id']} - $email@$domain - Status: $status ($validationStatus)");
            }

            $update->close();
            usleep(50000); // 50ms delay for SMTP
        }
    }

    $mainConn->close();
    logMessage("SMTP verification completed. Processed: $processed emails");
    return $processed;
}

// --- UPDATE CSV LIST COUNTS ---
function updateCsvListCounts($conn)
{
    $result = $conn->query("
        SELECT DISTINCT c.id
        FROM csv_list c
        JOIN emails e ON c.id = e.csv_list_id
    ");

    if ($result && $result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $campaignId = $row['id'];

            $stmt = $conn->prepare("
                SELECT 
                    COUNT(*) AS total_emails,
                    SUM(validation_status = 'valid') AS valid_count,
                    SUM(validation_status = 'invalid') AS invalid_count
                FROM emails
                WHERE csv_list_id = ?
            ");

            $stmt->bind_param("i", $campaignId);
            $stmt->execute();
            $stmt->bind_result($total, $valid, $invalid);
            $stmt->fetch();
            $stmt->close();

            $valid = $valid ?? 0;
            $invalid = $invalid ?? 0;
            $total = $total ?? 0;

            $updateStmt = $conn->prepare("
                UPDATE csv_list 
                SET 
                    total_emails = ?, 
                    valid_count = ?, 
                    invalid_count = ?,
                    status = 'completed'
                WHERE id = ?
            ");

            $updateStmt->bind_param("iiii", $total, $valid, $invalid, $campaignId);

            if (!$updateStmt->execute()) {
                logMessage("Failed to update counts for campaign $campaignId: " . $conn->error);
            } else {
                logMessage("Updated counts for campaign $campaignId: Total=$total, Valid=$valid, Invalid=$invalid");
            }

            $updateStmt->close();
        }
    }
}

// --- MAIN EXECUTION ---
try {
    logMessage("Script started");
    $start = microtime(true);

    // 1. DOMAIN VERIFICATION
    $domainProcessed = processDomainsParallel($dbConfig);
    $domainTime = microtime(true) - $start;

    // 2. SMTP VERIFICATION (only if all domains are verified)
    $conn = new mysqli(
        $dbConfig['host'],
        $dbConfig['username'],
        $dbConfig['password'],
        $dbConfig['name'],
        $dbConfig['port']
    );
    $conn->set_charset("utf8mb4");

    $remainingDomains = $conn->query("SELECT COUNT(*) FROM emails WHERE domain_verified = 0")->fetch_row()[0];
    $smtpProcessed = 0;
    $smtpTime = 0;

    if ($remainingDomains == 0) {
        $startSmtp = microtime(true);
        $smtpProcessed = processSmtpParallel($dbConfig);
        $smtpTime = microtime(true) - $startSmtp;
    } else {
        logMessage("SMTP verification skipped, $remainingDomains domains not yet verified");
    }

    // 3. UPDATE COUNTS
    updateCsvListCounts($conn);

    // 3.1. Set all running lists to completed after all processing
    $conn->query("UPDATE csv_list SET status = 'completed' WHERE status = 'running'");

    // 4. RESPONSE
    $totalResult = $conn->query("SELECT COUNT(*) as total FROM emails");
    $total = $totalResult->fetch_assoc()['total'];

    $conn->close();

    logMessage("Script completed. Total time: " . round(microtime(true) - $start, 2) . " seconds");

    echo json_encode([
        "status" => "success",
        "domain_processed" => $domainProcessed,
        "smtp_processed" => $smtpProcessed,
        "total" => $total,
        "domain_time_seconds" => round($domainTime, 2),
        "smtp_time_seconds" => round($smtpTime, 2)
    ]);

} catch (Exception $e) {
    logMessage("ERROR: " . $e->getMessage());
    echo json_encode([
        "status" => "error",
        "message" => $e->getMessage()
    ]);
}